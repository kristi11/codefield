# 404-page

This is a lightweight (less than 3kb) 404 page made with bootstrap 4.It includes only CSS.
Usage is very simple.Just copy and paste it into your project.
The only technology used here is bootstrap 4 and Material Design inspired colors which can be found 
here https://material.io/guidelines/style/color.html#color-color-tool
Feel free to use it as you please.
